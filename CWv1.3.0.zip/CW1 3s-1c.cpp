﻿/****************************************************************
*                     КАФЕДРА № 304 2 КУРС                      *
*---------------------------------------------------------------*
* Project Type  : Win32 Console Application                     *
* Project Name  : CW1 3s-1c                                     *
* File Name     : CW1 3s-1c.cpp                                 *
* Language      : C/C++                                         *
* Programmer(s) : Новиков К.А.                                  *
* Modifyed By   :                                               *
* Lit source    :                                               *
* Created       : 16/12/2022                                    *
* Last Revision : 16/12/2022                                    *
* Comment(s)    : Списки.                                       *
****************************************************************/

#include <iostream> //Консоль
#include <fstream> //Файлы
#include <Windows.h> //Виндовс
#include <chrono> //Время
#include <climits> //Константы
#include <iomanip> //Вы,вод
#include <string> //Строки
#include <conio.h> //"Консоль"

#include "Struct.h"
#include "Functions.h"
#include "Menu.h"

using namespace std;


int main()
{
    setlocale(LC_ALL, "RU");
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);
    srand(time(nullptr));
    SetConsoleTitle(L"БД института");
    system("CLS");
    cout << "Начало работы программы" << endl;
    //test();

    InstituteNode institute = createInstitutesList();
    
    char key;
    bool run = 1;
    while (false) {
        key = _getch();
        /*if (key == -32) {
            key = _getch();
        }*/
        cout << "Код:" << (int)key << endl;
        //consoleCursorGoToXY(0, 0);
        //cout << 123 << endl;
        //consoleCursorVisible(1);
    }

    cout << endl << "Студенты: " << endl;
    institute.printStudents();
    cout << endl << "Ведомости: " << endl;
    institute.printRecords();

    _getch();
}