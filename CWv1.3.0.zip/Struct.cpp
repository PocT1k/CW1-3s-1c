#include "Struct.h"

using namespace std;


void Node::coutNumber() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            cout << number[i][j];
        }
    }
    cout << endl;
}

void Node::copyNumber(string* str) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            this->number[i][j] = str[i][j];
        }
    }
}

void Node::printGeneral() {
    cout << surname << " " << name << " " << patronymic << " " << institute << faculty << training << "-" << course;
    cout << addZero(to_string(group), 2);
    cout << payment << "-" << year << " (���. " << department << ")";
}

void LineNode::coutError() {
    for (int i = 0; i < quantityErrorLine; i++) {
        cout << errorLine[i];
    }
    cout << " ";
    for (int i = 0; i < quantityErrorStudent; i++) {
        cout << errorStudent[i];
    }
    cout << " ";
    for (int i = 0; i < quantityErrorRecord; i++) {
        cout << errorRecord[i];
    }
    cout << " " << err << endl;
}

void LineNode::setErr() {
    for (int i = 0; i < quantityErrorLine; i++) {
        if (this->errorLine[i] == 1) { this->err = 1; }
    }
    for (int i = 0; i < quantityErrorStudent; i++) {
        if (this->errorStudent[i] == 1) { this->err = 1; }
    }
    for (int i = 0; i < quantityErrorRecord; i++) {
        if (this->errorRecord[i] == 1) { this->err = 1; }
    }
}

void LineNode::resetErr() {
    this->err = 0;
}

bool LineNode::getErr() {
    return this->err;
}

void LineNode::coutErr() {
    cout << this->err << endl;
}

void LineNode::createStr(string str) {
    this->str = str;
}

void LineNode::coutStr() {
    cout << this->str << endl;
}

string LineNode::getStr() {
    return this->str;
}

void LineNode::createLen(int len) {
    this->len = len;
}

void LineNode::addLen(int num) {
    this->len = this->len + num;
}

void LineNode::subLen(int num) {
    this->len = this->len - num;
}

int LineNode::getLen() {
    return this->len;
}

void InstituteNode::resetSM() {
    this->nodeSuccess = 0;
    this->nodeMistake = 0;
}

int InstituteNode::checkUniqueGroup(LineNode* line) {
    StudentNode* node = headStudentsList;
    while (node != nullptr) {
        if (compareGroup(node, line) == 1) {
            return 1; //������ �������
        }
        node = node->next;
    }
    return 0;
}

int InstituteNode::compareGroup(StudentNode* node, LineNode* line) {
    if ((node->institute == line->institute) && (node->faculty == line->faculty) && (node->course == line->course) && (node->group == line->group)) {
        if ((node->training != line ->training) || (node->payment != line->payment) || (node->year != line->year) || (node->department != line->department)) {
            return 1; // ��������� ������ � ���������� ����� �� �������
        }
        return 0;
    }
    return 0;
}

int InstituteNode::checkUniqueNumber(string* str) {
    StudentNode* node = headStudentsList;
    while (node != nullptr) {
        if (compareNumber(node->number, str) == 1) {
            return 1; //������ �������
        }
        node = node->next;
    }
    return 0;
}

int InstituteNode::compareNumber(string* str1, string* str2) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            if (str1[i][j] != str2[i][j]) {
                return 0; //�� �����
            }
        }
    }
    return 1;
}

int InstituteNode::compareString(string str1, string str2) {
    int i = 0;
    while ((str1[i] != '\0') && (str2[i] != '\0')) {
        if (str1[i] > str2[i]) {
            return 1;
        }
        if (str1[i] < str2[i]) {
            return 2;
        }
        i++;
    }
    return 0;
}

int InstituteNode::add(LineNode* line) {
    if (line->getErr() == 0) {
        line->errorUnique[0] = checkUniqueGroup(line);
        if (true) {
            if (line->type == 'S') {
                addStudent(line);
            }

            if (line->type == 'R') {
                addRecord(line);
            }
        }
    }

    else {
        nodeMistake++;
        if (failList == nullptr) {
            failList = line;
            lastFailList = line;
        }
        else {
            lastFailList->next = line;
            lastFailList = line;
        }
        return 0;
    }
    return -1;
}

int InstituteNode::addStudent(LineNode* line) {
    line->errorUnique[1] = checkUniqueNumber(line->number);
    if (line->errorUnique[1] == 0) {
        nodeSuccess++;
        StudentNode* newStydent = new StudentNode(line);
        //���������� � ���������� ������� �����
        if (headStudentsList == nullptr) {
            headStudentsList = newStydent;
            endStudentsList = newStydent;
        }
        else {
            StudentNode* node = endStudentsList;
            string FIO1 = "";
            string FIO2 = "";
            FIO1 = newStydent->surname + newStydent->name + newStydent->patronymic;
            FIO2 = node->surname + node->name + node->patronymic;

            bool comp = 0;
            while (true) {
                if (compareString(toSmallRus(FIO1), toSmallRus(FIO2)) != 2) {
                    comp = 1;
                    break;
                }
                if (node->prev != nullptr) {
                    node = node->prev;
                    FIO2 = node->surname + node->name + node->patronymic;
                }
                else {
                    break;
                }
            }

            if (!comp) { //��������� ��-�� ����, ��� nullptr
                addStartStudent(newStydent);
            }
            else {
                addAfterStudent(node, newStydent);
            }
        }
        return 0;
    }
    else {
        nodeMistake++;
        return 1;
    }
}

int InstituteNode::addRecord(LineNode* line) {
    nodeSuccess++;
    RecordNode* newRecord = new RecordNode(line);
    //���������� � ���������� ������� �����
    if (headRecordsList == nullptr) {
        headRecordsList = newRecord;
        endRecordsList = newRecord;
    }
    else {
        RecordNode* node = endRecordsList;
        string FIO1 = "";
        string FIO2 = "";
        FIO1 = newRecord->surname + newRecord->name + newRecord->patronymic;
        FIO2 = node->surname + node->name + node->patronymic;

        bool comp = 0;
        while (true) {
            if (compareString(toSmallRus(FIO1), toSmallRus(FIO2)) != 2) {
                comp = 1;
                break;
            }
            if (node->prev != nullptr) {
                node = node->prev;
                FIO2 = node->surname + node->name + node->patronymic;
            }
            else {
                break;
            }
        }

        if (!comp) { //��������� ��-�� ����, ��� nullptr
            addStartRecord(newRecord);
        }
        else {
            addAfterRecord(node, newRecord);
        }
    }
    return 0;
}

void InstituteNode::addStartStudent(StudentNode* newStydent) {
    headStudentsList->prev = newStydent;
    newStydent->next = headStudentsList;
    headStudentsList = newStydent;
}

void InstituteNode::addAfterStudent(StudentNode* node, StudentNode* newStydent) {
    newStydent->prev = node;
    newStydent->next = node->next;
    node->next = newStydent;
    if (endStudentsList == node) {
        endStudentsList = newStydent;
    }
}

void InstituteNode::addStartRecord(RecordNode* newRecord) {
    headRecordsList->prev = newRecord;
    newRecord->next = headRecordsList;
    headRecordsList = newRecord;
}
void InstituteNode::addAfterRecord(RecordNode* node, RecordNode* newRecord) {
    newRecord->prev = node;
    newRecord->next = node->next;
    node->next = newRecord;
    if (endRecordsList == node) {
        endRecordsList = newRecord;
    }
}

void InstituteNode::printStudents() {
    StudentNode* node = headStudentsList;
    while (node != nullptr) {
        node->printGeneral();
        cout << " ����." << node->date << " ���:" << node->gender << " �����:" << node->address;
        cout << endl;

        node = node->next;
    }
}

void InstituteNode::printRecords() {
    RecordNode* node = headRecordsList;
    while (node != nullptr) {
        node->printGeneral();
        cout << " ������." << node->date << " �������:" << node->subject << " ������:";
        cout << getValue(node->value);
        cout << " �������������:" << node->teacherSurname << " " << node->teacherName << " " << node->teacherPatronymic << " ����� ��������� �" << node->room;
        cout << endl;

        node = node->next;
    }
}

void InstituteNode::printFailList(int num) {
    LineNode* node = failList;
    while (node != nullptr) {
        node->coutStr();
        if (num) {
            Err err_Total[] = { err_Lenght, err_Syntax, err_Type, err_AmountData, err_Number, err_ChecksumNumber, err_Surname, err_Name, err_Patronymic, err_Institute, err_Faculty, err_Training, err_Course, err_Group, err_Payment, err_Year, err_Department, err_Date, err_ChecksumData };
            Err err_Student[] = { err_Gender, err_Address, err_Status };
            Err err_Record[] = { err_Subject, err_TeacherSurname, err_TeacherName, err_TeacherPatronymic, err_Value, err_Room };
            Err err_Unique[] = { err_UniqueNumber, err_UniqueGroup };

            for (int i = 0; i < node->quantityErrorLine; i++) {
                if (node->errorLine[i] != 0) {
                    err_Total[i](node->errorLine[i]);
                }
            }
            for (int i = 0; i < node->quantityErrorStudent; i++) {
                if (node->errorStudent[i] != 0) {
                    err_Student[i](node->errorStudent[i]);
                }
            }
            for (int i = 0; i < node->quantityErrorRecord; i++) {
                if (node->errorRecord[i] != 0) {
                    err_Record[i](node->errorRecord[i]);
                }
            }
            for (int i = 0; i < node->quantityErrorUnique; i++) {
                if (node->errorUnique[i] != 0) {
                    err_Unique[i](node->errorUnique[i]);
                }
            }
        }

        node = node->next;
    }
}