#include "Char.h"

using namespace std;


int getWordEnd(int num) {
    if ((num % 10 <= 0) || (num % 10 >= 5)) {
        return 0;
    }
    if ((num % 10 == 1)) {
        return 1;
    }
    return 2;
    //0 �������
    //1 ������
    //2 ������
    //3 ������
    //4 ������
    //5 �������
    //6 �������
    //7 �������
    //8 �������
    //9 �������
}

string deleteSpace(string& str) {
    str.erase(str.find(' '), 1);
    if (str[0] == ' ') {
        str = deleteSpace(str);
    }
    return str;
}

string addZero(string str, int num) {
    str = '0' + str;
    if (str.length() < num) {
        str = addZero(str, num);
    }
    return str;
}

string getValue(int val) {
    if (val == 1) {
        return "�/�";
    }
    else {
        return to_string(val);
    }
}

string getChecksum(string str) {
    if (str.size() % 2 == 1) {
        str = str + 'm';
    }
    int sum = 0;
    int mul;
    int div;
    for (int i = 0; i < str.size(); i = i + 2) {
        mul = str[i] * str[i + 1];
        div = str[i] / str[i + 1];
        sum = sum + mul + div;
    }
    while (sum % 10 == 0) {
        sum = sum / 10;
    }
    sum = sum % 1000000;
    str = to_string(sum);
    if (str.length() < 6) {
        str = addZero(str, 6);
    }
    return str;
}

bool isDigit(char ch) {
    if (('0' <= ch) && (ch <= '9')) {
        return 1;
    }
    return 0;
}

bool isBigRus(char ch) {
    if ((('�' <= ch) && (ch <= '�')) || (ch == '�')) {
        return 1;
    }
    return 0;
}

bool isSmallRus(char ch) {
    if ((('�' <= ch) && (ch <= '�')) || (ch == '�')) {
        return 1;
    }
    return 0;
}

bool checkNumber(char ch) {
    if ((isDigit(ch) == 1) || (isBigRus(ch) == 1) || (ch == ' ') || (ch == '-')) {
        return 1;
    }
    return 0;
}

string toSmallRus(string str) {
    int i = 0;
    while (str[i] != '\0') {
        if (str[i] == '�') {
            str[i] = '�';
        }
        else {
            if (isBigRus(str[i]) == 1) {
                str[i] = str[i] + 32;
            }
        }
        i++;
    }
    return str;
}