#include "Menu.h"

using namespace std;


HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
void consoleCursorGoToXY(short x, short y) {
    SetConsoleCursorPosition(hStdOut, { x, y });
}

void consoleCursorVisible(bool show) {
    CONSOLE_CURSOR_INFO structCursorInfo;
    GetConsoleCursorInfo(hStdOut, &structCursorInfo);
    structCursorInfo.bVisible = show;
    SetConsoleCursorInfo(hStdOut, &structCursorInfo);
}