#include "Functions.h"

using namespace std;


void test() {
    cout << "------------------------------------" << endl;
    //cout << INT_MAX << endl;


    //char c = 't';
    //cout << c << endl;

    //ofstream fout;
    //fout.open("��������1.ins");
    //fout << "123 �� ��� Yes No";
    //fout.close();
    //ifstream fin;
    //fin.open("��������1.ins");
    //string str1;
    //getline(fin, str1);
    //cout << str1 << endl;


    cout << "------------------------------------" << endl;
}

void readLine(string& strLine, LineNode* line) {
    line->printStr();

    line->errorLine[0] = checkLine_Lenght(strLine, line);
    if (line->errorLine[0] == 0) {
        line->errorLine[1] = checkLine_Syntax(strLine, line);
        line->errorLine[2] = checkLine_Type(strLine, line);
        line->errorLine[3] = checkLine_AmountData(strLine, line);
        line->setErr();
        if (line->getErr() == 0) {
            line->errorLine[4] = checkLine_Number(strLine, line);
            line->errorLine[5] = checkLine_ChecksumNumber(strLine, line);
            line->errorLine[6] = checkLine_Surname(strLine, line);
            line->errorLine[7] = checkLine_Name(strLine, line);
            line->errorLine[8] = checkLine_Patronymic(strLine, line);
            line->errorLine[9] = checkLine_Institute(strLine, line);
            line->errorLine[10] = checkLine_Faculty(strLine, line);
            line->errorLine[11] = checkLine_Training(strLine, line);
            line->errorLine[12] = checkLine_Course(strLine, line);
            line->errorLine[13] = checkLine_Group(strLine, line);
            line->errorLine[14] = checkLine_Payment(strLine, line);
            line->errorLine[15] = checkLine_Year(strLine, line);
            line->errorLine[16] = checkLine_Department(strLine, line);
            line->errorLine[17] = checkLine_Date(strLine, line);
            if (line->type == 'S') {
                line->errorStudent[0] = checkLine_Gender(strLine, line);
                line->errorStudent[1] = checkLine_Address(strLine, line);
                line->errorStudent[2] = checkLine_Status(strLine, line);
            }
            if (line->type == 'R') {
                line->errorRecord[0] = checkLine_Subject(strLine, line);
                line->errorRecord[1] = checkLine_Value(strLine, line);
                line->errorRecord[2] = checkLine_Room(strLine, line);
            }
        }
        line->errorLine[18] = checkLine_ChecksumData(strLine, line);
    }
    line->setErr();

    line->printError();
}

void readFileLine(istream& stream, InstituteNode& institute) {
    string strLine;
    getline(stream, strLine);
    LineNode* line = new LineNode;
    line->createStr(strLine);

    readLine(strLine, line);

    //institute.add(line);
}

int readFromFile(InstituteNode& institute) {
    ifstream instituteDataFile;
    instituteDataFile.open(institute.fileToOpen);

    if (!instituteDataFile) {
        cout << "������ ������ ����� " << institute.fileToOpen << endl;
        return 1;
    }
    if (!instituteDataFile.is_open()) {
        cout << "������ �������� ����� " << institute.fileToOpen << endl;
        return 2;
    }
    cout << "������ ���� " << institute.fileToOpen << endl;

    istream* stream = nullptr;
    stream = &instituteDataFile;

    while (!stream->eof()) {
        readFileLine(*stream, institute);
    }

    instituteDataFile.close();
    return 0;
}

InstituteNode createInstitutesList() {
    InstituteNode institute;
    institute.fileToOpen = institute.path + institute.file + institute.expansion;
    institute.fileTheName = institute.path + institute.file + institute.expansion;

    int error = readFromFile(institute);

    return institute;
}