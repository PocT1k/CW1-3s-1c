#include "Menu.h"

using namespace std;


HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
void consoleCursorGoToXY(short x, short y) {
    SetConsoleCursorPosition(hStdOut, { x, y });
}