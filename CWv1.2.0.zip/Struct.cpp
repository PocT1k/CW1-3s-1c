#include "Struct.h"

using namespace std;


void Node::printNumber() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            cout << number[i][j];
        }
    }
    cout << endl;
}

int StudentNode::getAmountData() {
    return this->amountData;
}

int RecordNode::getAmountData() {
    return this->amountData;
}

void LineNode::printError() {
    for (int i = 0; i < quantityErrorLine; i++) {
        cout << errorLine[i];
    }
    cout << " ";
    for (int i = 0; i < quantityErrorStudent; i++) {
        cout << errorStudent[i];
    }
    cout << " ";
    for (int i = 0; i < quantityErrorRecord; i++) {
        cout << errorRecord[i];
    }
    cout << " " << err << endl;
}

void LineNode::setErr() {
    for (int i = 0; i < quantityErrorLine; i++) {
        if (this->errorLine[i] == 1) { this->err = 1; }
    }
    for (int i = 0; i < quantityErrorStudent; i++) {
        if (this->errorStudent[i] == 1) { this->err = 1; }
    }
    for (int i = 0; i < quantityErrorRecord; i++) {
        if (this->errorRecord[i] == 1) { this->err = 1; }
    }
}

void LineNode::resetErr() {
    this->err = 0;
}

bool LineNode::getErr() {
    return this->err;
}

void LineNode::coutErr() {
    cout << this->err << endl;
}

void InstituteNode::add(LineNode line) {
    ;
}

void LineNode::createStr(string str) {
    this->str = str;
}

void LineNode::printStr() {
    cout << this->str << endl;
}

string LineNode::getStr() {
    return this->str;
}

void LineNode::createLen(int len) {
    this->len = len;
}

void LineNode::addLen(int num) {
    this->len = this->len + num;
}

void LineNode::subLen(int num) {
    this->len = this->len - num;
}

int LineNode::getLen() {
    return this->len;
}