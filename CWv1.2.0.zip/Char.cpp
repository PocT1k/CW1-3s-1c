#include "Char.h"

using namespace std;


string deleteSpace(string& str) {
    str.erase(str.find(' '), 1);
    if (str[0] == ' ') {
        str = deleteSpace(str);
    }
    return str;
}

string addZero(string str) {
    str = '0' + str;
    if (str.length() < 6) {
        str = addZero(str);
    }
    return str;
}

string getChecksum(string str) {
    if (str.size() % 2 == 1) {
        str = str + 'm';
    }
    int sum = 0;
    int mul;
    int div;
    for (int i = 0; i < str.size(); i = i + 2) {
        mul = str[i] * str[i + 1];
        div = str[i] / str[i + 1];
        sum = sum + mul + div;
    }
    while (sum % 10 == 0) {
        sum = sum / 10;
    }
    sum = sum % 1000000;
    str = to_string(sum);
    if (str.length() < 6) {
        str = addZero(str);
    }
    return str;
}

bool isDigit(char ch) {
    if (('0' <= ch) && (ch <= '9')) {
        return 1;
    }
    return 0;
}

bool isBigRus(char ch) {
    if (('�' <= ch) && (ch <= '�')) {
        return 1;
    }
    return 0;
}

bool isSmallRus(char ch) {
    if (('�' <= ch) && (ch <= '�')) {
        return 1;
    }
    return 0;
}

bool checkNumber(char ch) {
    if ((isDigit(ch) == 1) || (isBigRus(ch) == 1) || (ch == ' ') || (ch == '-')) {
        return 1;
    }
    return 0;
}

string getStringBeforeSep(string& strLine, LineNode* line) {
    int i = 0;
    while ((strLine[i] != '\0') && (strLine[i] != ';')) {
        i++;
    }
    string str = strLine.substr(0, i);
    line->subLen(i);
    if (strLine[i] != '\0') {
        strLine = strLine.substr(i + 1, strLine.length() - i - 1);

        if (str[0] == ' ') {
            str = deleteSpace(str);
        }
    }
    else {
        strLine = "";
    }

    //cout << "���������� " << i << " �������� " << str << endl;
    //cout << "����� " << line.str << endl;
    return str;
}

//int getSep(string& str, char sep) {
//    int i = 0;
//    while ((str[i] != '\0') && (str[i] != ' ') && (str[i] != sep)) {
//        i++;
//    }
//    return i;
//}