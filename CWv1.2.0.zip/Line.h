#ifndef CW_LINE_H
#define CW_LINE_H

#include <iostream> //�������
#include <fstream> //�����
#include <Windows.h> //�������
#include <chrono> //�����
#include <climits> //���������
#include <iomanip> //��,���
#include <string> //������
#include <conio.h> //"�������"

#include "Struct.h"
#include "Char.h"


int checkLine_Lenght(string& strLine, LineNode* line);
int checkLine_Syntax(string& strLine, LineNode* line);
int checkLine_Type(string& strLine, LineNode* line);
int checkLine_AmountData(string& strLine, LineNode* line);
int checkLine_Number(string& strLine, LineNode* line);
int checkLine_ChecksumNumber(string& strLine, LineNode* line);
int checkLine_Surname(string& strLine, LineNode* line);
int checkLine_Name(string& strLine, LineNode* line);
int checkLine_Patronymic(string& strLine, LineNode* line);
int checkLine_Institute(string& strLine, LineNode* line);
int checkLine_Faculty(string& strLine, LineNode* line);
int checkLine_Training(string& strLine, LineNode* line);
int checkLine_Course(string& strLine, LineNode* line);
int checkLine_Group(string& strLine, LineNode* line);
int checkLine_Payment(string& strLine, LineNode* line);
int checkLine_Year(string& strLine, LineNode* line);
int checkLine_Department(string& strLine, LineNode* line);
int checkLine_Date(string& strLine, LineNode* line);

int checkLine_Gender(string& strLine, LineNode* line);
int checkLine_Address(string& strLine, LineNode* line);
int checkLine_Status(string& strLine, LineNode* line);

int checkLine_Subject(string& strLine, LineNode* line);
int checkLine_Value(string& strLine, LineNode* line);
int checkLine_Room(string& strLine, LineNode* line);

int checkLine_ChecksumData(string& strLine, LineNode* line);

#endif