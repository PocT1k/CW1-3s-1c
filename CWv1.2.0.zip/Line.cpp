#include "Line.h"

using namespace std;


int checkLine_Lenght(string& strLine, LineNode* line) {
    if (strLine[0] == ' ') {
        strLine = deleteSpace(strLine);
    }

    while (strLine[line->getLen()] != '\0') {
        if (strLine[line->getLen()] == line->sep) {
            line->amountDataThis++;
        }
        line->addLen(1);
    }
    if (line->getLen() < line->lenStrMin) {
        return 1;
    }
    return 0;
}

int checkLine_Syntax(string& strLine, LineNode* line) {
    if ((strLine[0] != '[') || (strLine[2] != ']') || (strLine[3] != ':') || (strLine[8] != '-') || (strLine[13] != '-') || (strLine[18] != '-') || (strLine[23] != '-') || (strLine[28] != '-') || (strLine[33] != '-') || (strLine[38] != '-') || (strLine[43] != ';') || (strLine[50] != ';')) {
        return 1;
    }
    return 0;
}

int checkLine_Type(string& strLine, LineNode* line) {
    if (strLine[1] == 'S') {
        line->type = 'S';
    }
    if (strLine[1] == 'R') {
        line->type = 'R';
    }
    if (!line->type) {
        return 1;
    }
    return 0;
}

int checkLine_AmountData(string& strLine, LineNode* line) {
    if (line->type == 'S') {
        if (line->amountDataThis != line->amountDataMinStudent) {
            return 1;
        }
        return 0;
    }
    if (line->type == 'R') {
        if (line->amountDataThis != line->amountDataMinRecord) {
            return 2;
        }
        return 0;
    }
    if (line->amountDataThis != line->amountDataMin) {
        return 3;
    }
}

int checkLine_Number(string& strLine, LineNode* line) {
    string number = getStringBeforeSep(strLine, line);
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            //cout << number[4 + i * 5 + j] << " " << checkNumber(number[4 + i * 5 + j]) << " ";
            if (checkNumber(number[4 + i * 5 + j]) == 1) {
                line->number[i][j] = number[4 + i * 5 + j];
            }
            else {
                return 1;
            }
        }
    }
    return 0;
}

int checkLine_ChecksumNumber(string& strLine, LineNode* line) {
    string number;
    string checksumNumber = getStringBeforeSep(strLine, line);
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            number = number + line->number[i][j];
        }
    }

    //cout << getChecksum(number) << endl;

    if (getChecksum(number) != (checksumNumber)) {
        return 1;
    }
    line->checksumNumber = checksumNumber;
    return 0;
}

int checkLine_Surname(string& strLine, LineNode* line) {
    string surname = getStringBeforeSep(strLine, line);
    if (surname != "") {
        if (isBigRus(surname[0]) == 0) {
            return 1;
        }
        int i = 1;
        while (surname[i] != '\0') {
            if (isSmallRus(surname[i]) == 0) {
                return 2;
            }
            i++;
        }
        line->surname = surname;
        return 0;
    }
    return 0;
}

int checkLine_Name(string& strLine, LineNode* line) {
    string name = getStringBeforeSep(strLine, line);
    if (isBigRus(name[0]) == 0) {
        return 1;
    }
    int i = 1;
    while (name[i] != '\0') {
        if (isSmallRus(name[i]) == 0) {
            return 2;
        }
        i++;
    }
    line->name = name;
    return 0;
}

int checkLine_Patronymic(string& strLine, LineNode* line) {
    string patronymic = getStringBeforeSep(strLine, line);
    if (patronymic != "") {
        if (isBigRus(patronymic[0]) == 0) {
            return 1;
        }
        int i = 1;
        while (patronymic[i] != '\0') {
            if (isSmallRus(patronymic[i]) == 0) {
                return 2;
            }
            i++;
        }
        line->patronymic = patronymic;
        return 0;
    }
    return 0;
}

int checkLine_Institute(string& strLine, LineNode* line) {
    string institute = getStringBeforeSep(strLine, line);
    if (institute.length() != 1) {
        return 1;
    }
    if ((institute[0] != '�') && (institute[0] != 'M')) {
        return 2;
    }
    line->institute = '�';
    return 0;
}

int checkLine_Faculty(string& strLine, LineNode* line) {
    string faculty = getStringBeforeSep(strLine, line);
    if ((faculty.length() == 0) || (faculty.length() > 2)) {
        return 1;
    }
    int i = 0;
    while (faculty[i] != '\0') {
        if (isDigit(faculty[i]) == 0) {
            return 2;
        }
        i++;
    }
    line->faculty = stoi(faculty);
    return 0;
}

int checkLine_Training(string& strLine, LineNode* line) {
    string training = getStringBeforeSep(strLine, line);
    if (training.length() == 1) {
        if ((training[0] == '�') || (training[0] == 'O') || (training[0] == '�')) {
            if (training[0] == '�') {
                line->training = '�';
                return 0;
            }
            else {
                line->training = '�';
                return 0;
            }
        }
        return 1;
    }
    if ((training == "��") || (training == "O�")) {
        line->training = '��';
        return 0;
    }
    return 1;
}

int checkLine_Course(string& strLine, LineNode* line) {
    string course = getStringBeforeSep(strLine, line);
    if (course.length() != 1) {
        return 1;
    }
    if (isDigit(course[0]) == 0) {
        return 2;
    }
    int courseDigit = stoi(course);
    if ((courseDigit < 0) || (8 < courseDigit)) {
        return 3;
    }
    line->course = courseDigit;
    return 0;
}

int checkLine_Group(string& strLine, LineNode* line) {
    string group = getStringBeforeSep(strLine, line);
    if (group.length() != 2) {
        return 1;
    }
    if ((isDigit(group[0]) == 0) || (isDigit(group[1]) == 0)) {
        return 2;
    }
    line->group = stoi(group);
    return 0;
}

int checkLine_Payment(string& strLine, LineNode* line) {
    string payment = getStringBeforeSep(strLine, line);
    if (payment.length() == 1) {
        if ((payment[0] == '�') || (payment[0] == 'K') || (payment[0] == '�')) {
            if (payment[0] == '�') {
                line->payment = '�';
                return 0;
            }
            else {
                line->payment = '�';
                return 0;
            }
        }
        return 1;
    }
    if ((payment == "��") || (payment == "�k")) {
        line->payment = '��';
        return 0;
    }
    return 2;
}

int checkLine_Year(string& strLine, LineNode* line) {
    string year = getStringBeforeSep(strLine, line);
    if (year.length() != 4) {
        return 1;
    }
    for (int i = 0; i < 4; i++) {
        if (isDigit(year[i]) == 0) {
            return 2;
        }
    }
    int yearDigit = stoi(year);
    if (yearDigit < 1930) {
        return 3;
    }
    line->year = yearDigit;
    return 0;
}

int checkLine_Department(string& strLine, LineNode* line) {
    string department = getStringBeforeSep(strLine, line);
    if (department.length() != 3) {
        return 1;
    }
    for (int i = 0; i < 3; i++) {
        if (isDigit(department[i]) == 0) {
            return 2;
        }
    }
    line->department = stoi(department);
    return 0;
}

int checkLine_Date(string& strLine, LineNode* line) {
    string date = getStringBeforeSep(strLine, line);
    if (date.length() != 10) {
        return 1;
    }
    if ((date[4] != '.') || (date[7] != '.')) {
        return 2;
    }
    if ((isDigit(date[0]) == 0) || (isDigit(date[1]) == 0) || (isDigit(date[2]) == 0) || (isDigit(date[3]) == 0) || (isDigit(date[5]) == 0) || (isDigit(date[6]) == 0) || (isDigit(date[8]) == 0) || (isDigit(date[9]) == 0)) {
        return 3;
    }

    string date1str = date.substr(0, 4);
    int date1num = stoi(date1str);
    if ((date1num < 1930) || (date1num > 2023)) {
        return 4;
    }

    string date2str = date.substr(5, 2);
    int date2num = stoi(date2str);
    if ((date2num < 1) || (date2num > 12)) {
        return 5;
    }

    string date3str = date.substr(8, 2);
    int date3num = stoi(date3str);
    if ((date3num < 1) || (date3num > 31)) {
        return 6;
    }
    return 0;
}

int checkLine_Gender(string& strLine, LineNode* line) {
    string gender = getStringBeforeSep(strLine, line);
    if (gender.length() != 1) {
        return 1;
    }
    if ((gender[0] != '�') && (gender[0] != 'M') && (gender[0] != '�') && (gender[0] != '�') && (gender[0] != 'C')) {
        return 2;
    }
    if ((gender[0] == '�') || (gender[0] == 'M')) {
        line->gender = '�';
        return 0;
    }
    if ((gender[0] == '�') || (gender[0] == 'C')) {
        line->gender = '�';
        return 0;
    }
    line->gender = '�';
    return 0;
}

int checkLine_Address(string& strLine, LineNode* line) {
    string address = getStringBeforeSep(strLine, line);
    if (address == "") {
        return 1;
    }
    int i = 0;
    while (address[i] != '\0') {
        if ((isDigit(address[i]) == 0) && (isSmallRus(address[i]) == 0) && (isBigRus(address[i]) == 0) && (address[i] != ' ') && (address[i] != '-') && (address[i] != '.') && (address[i] != ',')) {
            cout << address << " " << i << endl;
            return 2;
        }
        i++;
    }
    line->address = address;
    return 0;
}

int checkLine_Status(string& strLine, LineNode* line) {
    string status = getStringBeforeSep(strLine, line);
    if (status.length() != 1) {
        return 1;
    }
    if (isDigit(status[0]) == 0) {
        return 2;
    }
    int statusDigit = stoi(status);
    if ((statusDigit < 0) || (2 < statusDigit)) {
        return 3;
    }
    line->status = statusDigit;
    return 0;
}

int checkLine_Subject(string& strLine, LineNode* line) {
    string subject = getStringBeforeSep(strLine, line);
    int i = 0;
    while (subject[i] != '\0') {
        if ((isDigit(subject[i]) == 0) && (isSmallRus(subject[i]) == 0) && (isBigRus(subject[i]) == 0) && (subject[i] != ' ') && (subject[i] != '-')) {
            return 1;
        }
        i++;
    }
    line->subject = subject;
    return 0;
}

int checkLine_Value(string& strLine, LineNode* line) {
    string value = getStringBeforeSep(strLine, line);
    if (value.length() != 1) {
        return 1;
    }
    if (isDigit(value[0]) == 0) {
        return 2;
    }
    int valueDigit = stoi(value);
    if ((valueDigit < 1) || (5 < valueDigit)) {
        return 3;
    }
    line->value = valueDigit;
    return 0;
}

int checkLine_Room(string& strLine, LineNode* line) {
    string room = getStringBeforeSep(strLine, line);
    int i = 0;
    while (room[i] != '\0') {
        if (isDigit(room[i]) == 0) {
            return 1;
        }
        i++;
    }
    line->room = stoi(room);
    return 0;
}

int checkLine_ChecksumData(string& strLine, LineNode* line) {
    string data = "";
    string checksumData = getStringBeforeSep(strLine, line);
    string number;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            number = number + line->number[i][j];
        }
    }
    data = data + line->type + number + line->checksumNumber + line->surname + line->name + line->patronymic + line->institute + to_string(line->faculty) + line->training + to_string(line->course) + to_string(line->group) + line->payment + to_string(line->year) + to_string(line->department) + line->date;
    if (line->type == 'S') {
        data = data + line->gender + line->address + to_string(line->status);
    }
    if (line->type == 'R') {
        data = data + line->subject + to_string(line->value) + to_string(line->room);
    }

    //cout << getChecksum(data) << endl;

    if (getChecksum(data) != (checksumData)) {
        return 1;
    }
    line->checksumData = checksumData;
    return 0;
}
