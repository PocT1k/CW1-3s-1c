#include "Struct.h"

using namespace std;


string getStringBeforeSep(string& strLine, LineNode* line) {
    int i = 0;
    while ((strLine[i] != '\0') && (strLine[i] != ';')) {
        i++;
    }
    string str = strLine.substr(0, i);
    line->subLen(i);
    if (strLine[i] != '\0') {
        strLine = strLine.substr(i + 1, strLine.length() - i - 1);

        if (str[0] == ' ') {
            str = deleteSpace(str);
        }
    }
    else {
        strLine = "";
    }

    //cout << "���������� " << i << " �������� " << str << endl;
    //cout << "����� " << line.str << endl;
    return str;
}

int checkLine_Fictition(string& strLine, LineNode* line) {
    return 0;
}

int checkLine_Lenght(string& strLine, LineNode* line) {
    while (strLine[line->getLen()] != '\0') {
        if (strLine[line->getLen()] == line->sep) {
            line->amountDataThis++;
        }
        line->addLen(1);
    }
    if (line->getLen() < line->lenStrMin) {
        return 1;
    }
    return 0;
}

int checkLine_Syntax(string& strLine, LineNode* line) {
    if ((strLine[0] != '[') || (strLine[2] != ']') || (strLine[3] != ':') || (strLine[8] != '-') || (strLine[13] != '-') || (strLine[18] != '-') || (strLine[23] != '-') || (strLine[28] != '-') || (strLine[33] != '-') || (strLine[38] != '-') || (strLine[43] != ';') || (strLine[50] != ';')) {
        return 1;
    }
    return 0;
}

int checkLine_Type(string& strLine, LineNode* line) {
    if (strLine[1] == 'S') {
        line->type = 'S';
    }
    if (strLine[1] == 'R') {
        line->type = 'R';
    }
    if (!line->type) {
        return 1;
    }
    return 0;
}

int checkLine_AmountData(string& strLine, LineNode* line) {
    if (line->type == 'S') {
        if (line->amountDataThis != line->amountDataMinStudent - 1) {
            return 1;
        }
        return 0;
    }
    if (line->type == 'R') {
        if (line->amountDataThis != line->amountDataMinRecord - 1) {
            return 2;
        }
        return 0;
    }
    if (line->amountDataThis != line->amountDataMin - 1) {
        return 3;
    }
}

int checkLine_Number(string& strLine, LineNode* line) {
    string number = getStringBeforeSep(strLine, line);
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            //cout << number[4 + i * 5 + j] << " " << checkNumber(number[4 + i * 5 + j]) << " ";
            if (checkNumber(number[4 + i * 5 + j]) == 1) {
                line->number[i][j] = number[4 + i * 5 + j];
            }
            else {
                return 1;
            }
        }
    }
    return 0;
}

int checkLine_ChecksumNumber(string& strLine, LineNode* line) {
    string number;
    string checksumNumber = getStringBeforeSep(strLine, line);
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            number = number + line->number[i][j];
        }
    }

    //cout << getChecksum(number) << endl;

    if (getChecksum(number) != (checksumNumber)) {
        return 1;
    }
    line->checksumNumber = checksumNumber;
    return 0;
}

int checkLine_Surname(string& strLine, LineNode* line) {
    string surname = getStringBeforeSep(strLine, line);
    if (surname != "") {
        if (isBigRus(surname[0]) == 0) {
            return 1;
        }
        int i = 1;
        while (surname[i] != '\0') {
            if ((isSmallRus(surname[i]) != 1) && (surname[i] != '-') && (surname[i] != ' ')) {
                return 2;
            }
            i++;
        }
        line->surname = surname;
        return 0;
    }
    return 0;
}

int checkLine_Name(string& strLine, LineNode* line) {
    string name = getStringBeforeSep(strLine, line);
    if (name == "") {
        return 1;
    }
    if (isBigRus(name[0]) == 0) {
        return 2;
    }
    int i = 1;
    while (name[i] != '\0') {
        if ((isSmallRus(name[i]) != 1) && (name[i] != '-') && (name[i] != ' ')) {
            return 3;
        }
        i++;
    }
    line->name = name;
    return 0;
}

int checkLine_Patronymic(string& strLine, LineNode* line) {
    string patronymic = getStringBeforeSep(strLine, line);
    if (patronymic != "") {
        if (isBigRus(patronymic[0]) == 0) {
            return 1;
        }
        int i = 1;
        while (patronymic[i] != '\0') {
            if ((isSmallRus(patronymic[i]) != 1) && (patronymic[i] != '-') && (patronymic[i] != ' ')) {
                return 2;
            }
            i++;
        }
        line->patronymic = patronymic;
        return 0;
    }
    return 0;
}

int checkLine_Institute(string& strLine, LineNode* line) {
    string institute = getStringBeforeSep(strLine, line);
    if (institute.length() != 1) {
        return 1;
    }
    if ((institute[0] != '�') && (institute[0] != 'M')) {
        return 2;
    }
    line->institute = '�';
    return 0;
}

int checkLine_Faculty(string& strLine, LineNode* line) {
    string faculty = getStringBeforeSep(strLine, line);
    if ((faculty.length() < 1) || (2 < faculty.length())) {
        return 1;
    }
    int i = 0;
    while (faculty[i] != '\0') {
        if (isDigit(faculty[i]) == 0) {
            return 2;
        }
        i++;
    }
    line->faculty = stoi(faculty);
    return 0;
}

int checkLine_Training(string& strLine, LineNode* line) {
    string training = getStringBeforeSep(strLine, line);
    if (training.length() == 1) {
        if ((training[0] == '�') || (training[0] == 'O') || (training[0] == '�')) {
            if (training[0] == '�') {
                line->training = "�";
                return 0;
            }
            else {
                line->training = "�";
                return 0;
            }
        }
        return 1;
    }
    if ((training == "��") || (training == "O�")) {
        line->training = "��";
        return 0;
    }
    return 2;
}

int checkLine_Course(string& strLine, LineNode* line) {
    string course = getStringBeforeSep(strLine, line);
    if (course.length() != 1) {
        return 1;
    }
    if (isDigit(course[0]) == 0) {
        return 2;
    }
    int courseDigit = stoi(course);
    if ((courseDigit < 0) || (8 < courseDigit)) {
        return 3;
    }
    line->course = courseDigit;
    return 0;
}

int checkLine_Group(string& strLine, LineNode* line) {
    string group = getStringBeforeSep(strLine, line);
    if (group.length() != 2) {
        return 1;
    }
    if ((isDigit(group[0]) == 0) || (isDigit(group[1]) == 0)) {
        return 2;
    }
    int groupDigit = stoi(group);
    if (groupDigit == 0) {
        return 3;
    }
    line->group = groupDigit;
    return 0;
}

int checkLine_Payment(string& strLine, LineNode* line) {
    string payment = getStringBeforeSep(strLine, line);
    if (payment.length() == 1) {
        if ((payment[0] == '�') || (payment[0] == 'K') || (payment[0] == '�')) {
            if (payment[0] == '�') {
                line->payment = "�";
                return 0;
            }
            else {
                line->payment = "�";
                return 0;
            }
        }
        return 1;
    }
    if ((payment == "��") || (payment == "�k")) {
        line->payment = "��";
        return 0;
    }
    return 2;
}

int checkLine_Year(string& strLine, LineNode* line) {
    string year = getStringBeforeSep(strLine, line);
    if (year.length() != 4) {
        return 1;
    }
    for (int i = 0; i < 4; i++) {
        if (isDigit(year[i]) == 0) {
            return 2;
        }
    }
    int yearDigit = stoi(year);
    if (yearDigit < 1930) {
        return 3;
    }
    line->year = yearDigit;
    return 0;
}

int checkLine_Department(string& strLine, LineNode* line) {
    string department = getStringBeforeSep(strLine, line);
    if (department.length() != 3) {
        return 1;
    }
    for (int i = 0; i < 3; i++) {
        if (isDigit(department[i]) == 0) {
            return 2;
        }
    }
    int departmentDigit = stoi(department);
    if (departmentDigit == 0) {
        return 3;
    }
    line->department = departmentDigit;
    return 0;
}

int checkLine_Date(string& strLine, LineNode* line) {
    string date = getStringBeforeSep(strLine, line);
    if (date.length() != 10) {
        return 1;
    }
    if ((date[4] != '.') || (date[7] != '.')) {
        return 2;
    }
    if ((isDigit(date[0]) == 0) || (isDigit(date[1]) == 0) || (isDigit(date[2]) == 0) || (isDigit(date[3]) == 0) || (isDigit(date[5]) == 0) || (isDigit(date[6]) == 0) || (isDigit(date[8]) == 0) || (isDigit(date[9]) == 0)) {
        return 3;
    }

    string date1str = date.substr(0, 4);
    int date1num = stoi(date1str);
    if ((date1num < 1930) || (date1num > 2023)) {
        return 4;
    }

    string date2str = date.substr(5, 2);
    int date2num = stoi(date2str);
    if ((date2num < 1) || (date2num > 12)) {
        return 5;
    }

    string date3str = date.substr(8, 2);
    int date3num = stoi(date3str);
    if ((date3num < 1) || (date3num > 31)) {
        return 6;
    }
    line->date = date;
    return 0;
}

int checkLine_Gender(string& strLine, LineNode* line) {
    string gender = getStringBeforeSep(strLine, line);
    if (gender.length() != 1) {
        return 1;
    }
    if ((gender[0] != '�') && (gender[0] != 'M') && (gender[0] != '�') && (gender[0] != '�') && (gender[0] != 'C')) {
        return 2;
    }
    if ((gender[0] == '�') || (gender[0] == 'M')) {
        line->gender = '�';
        return 0;
    }
    if ((gender[0] == '�') || (gender[0] == 'C')) {
        line->gender = '�';
        return 0;
    }
    line->gender = '�';
    return 0;
}

int checkLine_Address(string& strLine, LineNode* line) {
    string address = getStringBeforeSep(strLine, line);
    if (address == "") {
        return 1;
    }
    int i = 0;
    while (address[i] != '\0') {
        if ((isDigit(address[i]) == 0) && (isSmallRus(address[i]) == 0) && (isBigRus(address[i]) == 0) && (address[i] != ' ') && (address[i] != '-') && (address[i] != '.') && (address[i] != ',')) {
            cout << address << " " << i << endl;
            return 2;
        }
        i++;
    }
    line->address = address;
    return 0;
}

int checkLine_Status(string& strLine, LineNode* line) {
    string status = getStringBeforeSep(strLine, line);
    if (status.length() != 1) {
        return 1;
    }
    if (isDigit(status[0]) == 0) {
        return 2;
    }
    int statusDigit = stoi(status);
    if ((statusDigit < 0) || (2 < statusDigit)) {
        return 3;
    }
    line->status = statusDigit;
    return 0;
}

int checkLine_Subject(string& strLine, LineNode* line) {
    string subject = getStringBeforeSep(strLine, line);
    if (subject == "") {
        return 1;
    }
    int i = 0;
    while (subject[i] != '\0') {
        if ((isDigit(subject[i]) == 0) && (isSmallRus(subject[i]) == 0) && (isBigRus(subject[i]) == 0) && (subject[i] != ' ') && (subject[i] != '-')) {
            return 2;
        }
        i++;
    }
    line->subject = subject;
    return 0;
}

int checkLine_TeacherSurname(string& strLine, LineNode* line) {
    string surname = getStringBeforeSep(strLine, line);
    if (surname != "") {
        if (isBigRus(surname[0]) == 0) {
            return 1;
        }
        int i = 1;
        while (surname[i] != '\0') {
            if ((isSmallRus(surname[i]) != 1) && (surname[i] != '-') && (surname[i] != ' ')) {
                return 2;
            }
            i++;
        }
        line->teacherSurname = surname;
        return 0;
    }
    return 0;
}

int checkLine_TeacherName(string& strLine, LineNode* line) {
    string name = getStringBeforeSep(strLine, line);
    if (name == "") {
        return 1;
    }
    if (isBigRus(name[0]) == 0) {
        return 2;
    }
    int i = 1;
    while (name[i] != '\0') {
        if ((isSmallRus(name[i]) != 1) && (name[i] != '-') && (name[i] != ' ')) {
            return 3;
        }
        i++;
    }
    line->teacherName = name;
    return 0;
}

int checkLine_TeacherPatronymic(string& strLine, LineNode* line) {
    string patronymic = getStringBeforeSep(strLine, line);
    if (patronymic != "") {
        if (isBigRus(patronymic[0]) == 0) {
            return 1;
        }
        int i = 1;
        while (patronymic[i] != '\0') {
            if ((isSmallRus(patronymic[i]) != 1) && (patronymic[i] != '-') && (patronymic[i] != ' ')) {
                return 2;
            }
            i++;
        }
        line->teacherPatronymic = patronymic;
        return 0;
    }
    return 0;
}

int checkLine_Value(string& strLine, LineNode* line) {
    string value = getStringBeforeSep(strLine, line);
    if (value.length() == 1) {
        if (isDigit(value[0]) == 0) {
            return 1;
        }
        int valueDigit = stoi(value);
        if ((valueDigit < 1) || (5 < valueDigit)) {
            return 2;
        }
        line->value = valueDigit;
        return 0;
    }
    if (value.length() == 3) {
        if (value == "�/�") {
            line->value = 1;
            return 0;
        }
    }
    return 3;
}

int checkLine_Room(string& strLine, LineNode* line) {
    string room = getStringBeforeSep(strLine, line);
    if (room == "") {
        return 1;
    }
    int i = 0;
    while (room[i] != '\0') {
        if (isDigit(room[i]) == 0) {
            return 2;
        }
        i++;
    }
    line->room = stoi(room);
    return 0;
}

int checkLine_ChecksumData(string& strLine, LineNode* line) {
    string data = "";
    string checksumData = getStringBeforeSep(strLine, line);
    string number;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            number = number + line->number[i][j];
        }
    }
    data = data + line->type + number + line->checksumNumber + line->surname + line->name + line->patronymic + line->institute + to_string(line->faculty) + line->training + to_string(line->course) + to_string(line->group) + line->payment + to_string(line->year) + to_string(line->department) + line->date;
    if (line->type == 'S') {
        data = data + line->gender + line->address + to_string(line->status);
    }
    if (line->type == 'R') {
        data = data + line->subject + line->teacherSurname + line->teacherName + line->teacherPatronymic + to_string(line->value) + to_string(line->room);
    }

    //cout << getChecksum(data) << endl;

    if (getChecksum(data) != (checksumData)) {
        return 1;
    }
    line->checksumData = checksumData;
    return 0;
}

void Node::coutNumber() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            cout << number[i][j];
        }
    }
    cout << endl;
}

void Node::copyNumber(string* str) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            this->number[i][j] = str[i][j];
        }
    }
}

void Node::printGeneral() {
    cout << surname << " " << name << " " << patronymic << " " << institute << faculty << training << "-" << course;
    cout << addZero(to_string(group), 2);
    cout << payment << "-" << year << " (���. " << department << ")";
}

void Node::writeGeneral(ostream& stream, Node* node) {
    stream << ";" << node->checksumNumber << ";" << node->surname << ";" << node->name << ";" << node->patronymic << ";" << node->institute << ";" << node->faculty << ";" << node->training << ";" << node->course << ";" << node->group << ";" << node->payment << ";" << node->year << ";" << node->department << ";" << node->date;
    stream << ";";
}

void LineNode::coutError() {
    for (int i = 0; i < quantityErrorLine; i++) {
        cout << errorLine[i];
    }
    cout << " ";
    for (int i = 0; i < quantityErrorStudent; i++) {
        cout << errorStudent[i];
    }
    cout << " ";
    for (int i = 0; i < quantityErrorRecord; i++) {
        cout << errorRecord[i];
    }
    cout << " " << err << endl;
}

void LineNode::setErr() {
    for (int i = 0; i < quantityErrorLine; i++) {
        if (this->errorLine[i] == 1) { this->err = 1; }
    }
    for (int i = 0; i < quantityErrorStudent; i++) {
        if (this->errorStudent[i] == 1) { this->err = 1; }
    }
    for (int i = 0; i < quantityErrorRecord; i++) {
        if (this->errorRecord[i] == 1) { this->err = 1; }
    }
}

void LineNode::resetErr() {
    this->err = 0;
}

bool LineNode::getErr() {
    return this->err;
}

void LineNode::coutErr() {
    cout << this->err << endl;
}

void LineNode::createStr(string str) {
    this->str = str;
}

void LineNode::coutStr() {
    cout << this->str << endl;
}

string LineNode::getStr() {
    return this->str;
}

void LineNode::createLen(int len) {
    this->len = len;
}

void LineNode::addLen(int num) {
    this->len = this->len + num;
}

void LineNode::subLen(int num) {
    this->len = this->len - num;
}

int LineNode::getLen() {
    return this->len;
}

void LineNode::coutCreateStudentCart(string arrFields[], int size1) {
    //cout << "| ��������         12345678901234567890        |" << endl;
    string arrFillIn[] = { "�������", "�������", "���", "��������", "��������", "���������", "����� ��������", "����", "������", "�������. ������", "��� �����������", "�������", "���� ��������", "���", "�����" };
    int size2 = sizeof(arrFillIn) / sizeof(arrFillIn[0]);
    if (size1 != size2) {
        cout << "������ - ������ �������� ������ ����� CreateStudentCart" << endl;
        exit(1);
    }
    if (size1 != amountDataMinStudent - 4) {
        cout << "������ - ������ �������� ������ ����� CreateStudentCart" << endl;
        exit(1);
    }
    consoleCoutLetter("|", 0, size1);
    consoleCoutLetter("|", 47, size1);
    consoleCoutMesage(arrFillIn, 2, size1);
    consoleCoutMesage(arrFields, 19, size1);
}

void LineNode::createStydent(LineNode* line) {
    system("CLS");
    this->type = 'S';
    string arrFields[] = { "", "_________________________", "_________________________", "_________________________", "_", "__", "__", "_", "__", "__", "____", "___", "__________", "_", "_________________________"};
    int size = sizeof(arrFields) / sizeof(arrFields[0]);
    coutCreateStudentCart(arrFields, size);

    checkLine checkLineFile_Total[] = { checkLine_Fictition, checkLine_Surname, checkLine_Name, checkLine_Patronymic, checkLine_Institute, checkLine_Faculty, checkLine_Training , checkLine_Course, checkLine_Group, checkLine_Payment, checkLine_Year, checkLine_Department, checkLine_Date };
    checkLine checkLineFile_Student[] = { checkLine_Gender, checkLine_Address };
    int size_checkLineFile_Total = sizeof(checkLineFile_Total) / sizeof(checkLineFile_Total[0]);
    int size_checkLineFile_Student = sizeof(checkLineFile_Student) / sizeof(checkLineFile_Student[0]);
    
    for (int i = 4; i < (size_checkLineFile_Total + 4); i++) {
        if (i == 4) {
            continue;
        }
        string strLine = "";
        int outFlag = getConsole(strLine, 19, i - 4, arrFields[i - 4].length());
        line->errorLine[i] = checkLineFile_Total[i - 4](strLine, line);
    }
    for (int i = 0; i < size_checkLineFile_Student; i++) {
        string strLine = "";
        //getConsole(strLine, 19, i - 4, arrFields[i - 4].length());
        //line->errorLine[i] = checkLineFile_Student[i](strLine, line);
    }
    line->status = 1;
}

void createRecord(LineNode* line) {

}

StudentNode* StudentNode::nextNode(StudentNode* node) {
    return node->next;
}

RecordNode* RecordNode::nextNode(RecordNode* node) {
    return node->next;
}

LineNode* LineNode::nextNode(LineNode* node) {
    return node->next;
}

void InstituteNode::resetSM() {
    this->nodeSuccess = 0;
    this->nodeMistake = 0;
}

int InstituteNode::checkUniqueGroup(LineNode* line) {
    StudentNode* node = headStudentsList;
    while (node != nullptr) {
        if (compareGroup(node, line) != 0) {
            return compareGroup(node, line); //������ �������
        }
        node = node->next;
    }
    return 0;
}

int InstituteNode::compareGroup(StudentNode* node, LineNode* line) {
    if ((node->institute == line->institute) && (node->faculty == line->faculty) && (node->course == line->course) && (node->group == line->group)) {
        if (node->training != line ->training) {
            return 1; // ��������� ������ � ���������� ����� �� �������
        }
        if (node->payment != line->payment) {
            return 2;
        }
        if (node->year != line->year) {
            return 3;
        }
        if (node->department != line->department) {
            return 4;
        }
        return 0;
    }
    return 0;
}

int InstituteNode::checkUniqueNumber(string* str) {
    StudentNode* node = headStudentsList;
    while (node != nullptr) {
        if ((compareNumber(node->number, str)) == 1) {
            return 1; //������ �������
        }
        node = node->next;
    }
    return 0;
}

int InstituteNode::compareNumber(string* str1, string* str2) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            if (str1[i][j] != str2[i][j]) {
                return 0; //�� �����
            }
        }
    }
    return 1;
}

int InstituteNode::compareString(string str1, string str2) {
    int i = 0;
    while ((str1[i] != '\0') && (str2[i] != '\0')) {
        if (str1[i] > str2[i]) {
            return 1;
        }
        if (str1[i] < str2[i]) {
            return 2;
        }
        i++;
    }
    return 0;
}

int InstituteNode::add(LineNode* line) {
    if (line->getErr() == 0) {
        line->errorUnique[0] = checkUniqueGroup(line);
        if (line->errorUnique[0] == 0) {
            if (line->type == 'S') {
                addStudent(line);
                return 0;
            }

            if (line->type == 'R') {
                addRecord(line);
                return 0;
            }
        }
        else {
            addFail(line);
            return 0;
        }
    }

    else {
        addFail(line);
        return 0;
    }
    return -1;
}

int InstituteNode::addStudent(LineNode* line) {
    line->errorUnique[1] = checkUniqueNumber(line->number);
    if (line->errorUnique[1] == 0) {
        nodeSuccess++;
        StudentNode* newStydent = new StudentNode(line);
        //���������� � ���������� ������� �����
        if (headStudentsList == nullptr) {
            headStudentsList = newStydent;
            endStudentsList = newStydent;
        }
        else {
            StudentNode* node = endStudentsList;
            string FIO1 = "";
            string FIO2 = "";
            FIO1 = newStydent->surname + newStydent->name + newStydent->patronymic;
            FIO2 = node->surname + node->name + node->patronymic;

            bool comp = 0;
            while (true) {
                if (compareString(toSmallRus(FIO1), toSmallRus(FIO2)) != 2) {
                    comp = 1;
                    break;
                }
                if (node->prev != nullptr) {
                    node = node->prev;
                    FIO2 = node->surname + node->name + node->patronymic;
                }
                else {
                    break;
                }
            }

            if (!comp) { //��������� ��-�� ����, ��� nullptr
                addStartStudent(newStydent);
            }
            else {
                addAfterStudent(node, newStydent);
            }
        }
        return 0;
    }
    else {
        addFail(line);
        return 1;
    }
}

int InstituteNode::addRecord(LineNode* line) {
    nodeSuccess++;
    RecordNode* newRecord = new RecordNode(line);
    //���������� � ���������� ������� �����
    if (headRecordsList == nullptr) {
        headRecordsList = newRecord;
        endRecordsList = newRecord;
    }
    else {
        RecordNode* node = endRecordsList;
        string FIO1 = "";
        string FIO2 = "";
        FIO1 = newRecord->surname + newRecord->name + newRecord->patronymic;
        FIO2 = node->surname + node->name + node->patronymic;

        bool comp = 0;
        while (true) {
            if (compareString(toSmallRus(FIO1), toSmallRus(FIO2)) != 2) {
                comp = 1;
                break;
            }
            if (node->prev != nullptr) {
                node = node->prev;
                FIO2 = node->surname + node->name + node->patronymic;
            }
            else {
                break;
            }
        }

        if (!comp) { //��������� ��-�� ����, ��� nullptr
            addStartRecord(newRecord);
        }
        else {
            addAfterRecord(node, newRecord);
        }
    }
    return 0;
}

int InstituteNode::addFail(LineNode* line) {
    nodeMistake++;
    if (failList == nullptr) {
        failList = line;
        lastFailList = line;
    }
    else {
        lastFailList->next = line;
        lastFailList = line;
    }
    return 0;
}

void InstituteNode::deleteAll() {
    cout << endl;
    cout << "������ �������� ������" << endl;

    StudentNode* nodeS = headStudentsList;
    while (nodeS != nullptr) {
        nodeS = headStudentsList->next;
        delete headStudentsList;
        headStudentsList = nodeS;
        nodeSuccess++;
    }

    RecordNode* nodeR = headRecordsList;
    while (nodeR != nullptr) {
        nodeR = headRecordsList->next;
        delete headRecordsList;
        headRecordsList = nodeR;
        nodeSuccess++;
    }

    LineNode* nodeF = failList;
    while (nodeF != nullptr) {
        nodeF = failList->next;
        delete failList;
        failList = nodeF;
        nodeSuccess++;
    }

    cout << "�������� ���������, ������� " << nodeSuccess << " " << worlEnd_������[getWordEnd(nodeSuccess)] << "(� ��� ����� ������������)" << endl;
    resetSM();
}

void InstituteNode::addStartStudent(StudentNode* newStydent) {
    headStudentsList->prev = newStydent;
    newStydent->next = headStudentsList;
    headStudentsList = newStydent;
}

void InstituteNode::addAfterStudent(StudentNode* node, StudentNode* newStydent) {
    newStydent->prev = node;
    newStydent->next = node->next;
    node->next = newStydent;
    if (endStudentsList == node) {
        endStudentsList = newStydent;
    }
}

void InstituteNode::addStartRecord(RecordNode* newRecord) {
    headRecordsList->prev = newRecord;
    newRecord->next = headRecordsList;
    headRecordsList = newRecord;
}
void InstituteNode::addAfterRecord(RecordNode* node, RecordNode* newRecord) {
    newRecord->prev = node;
    newRecord->next = node->next;
    node->next = newRecord;
    if (endRecordsList == node) {
        endRecordsList = newRecord;
    }
}

void InstituteNode::printStudents() {
    cout << endl;
    cout << "������ ���������: " << endl;
    StudentNode* node = headStudentsList;
    while (node != nullptr) {
        node->printGeneral();
        cout << " ����." << node->date << " ���:" << node->gender << " �����:" << node->address;
        cout << getStatus(node->status);
        cout << endl;

        node = node->next;
    }
}

void InstituteNode::printRecords() {
    cout << endl;
    cout << endl << "������ ����������: " << endl;
    RecordNode* node = headRecordsList;
    while (node != nullptr) {
        node->printGeneral();
        cout << " ������." << node->date << " �������:" << node->subject << " ������:";
        cout << getValue(node->value);
        cout << " �������������:" << node->teacherSurname << " " << node->teacherName << " " << node->teacherPatronymic << " ����� ��������� �" << node->room;
        cout << endl;

        node = node->next;
    }
}

void InstituteNode::printFailList(int num) {
    cout << endl;
    LineNode* node = failList;
    while (node != nullptr) {
        node->coutStr();
        if (num) {
            Err err_Total[] = { err_Lenght, err_Syntax, err_Type, err_AmountData, err_Number, err_ChecksumNumber, err_Surname, err_Name, err_Patronymic, err_Institute, err_Faculty, err_Training, err_Course, err_Group, err_Payment, err_Year, err_Department, err_Date, err_ChecksumData };
            Err err_Student[] = { err_Gender, err_Address, err_Status };
            Err err_Record[] = { err_Subject, err_TeacherSurname, err_TeacherName, err_TeacherPatronymic, err_Value, err_Room };
            Err err_Unique[] = { err_UniqueGroup, err_UniqueNumber, err_UniqueName };

            for (int i = 0; i < node->quantityErrorLine; i++) {
                if (node->errorLine[i] != 0) {
                    err_Total[i](node->errorLine[i]);
                    cout << endl;
                }
            }
            for (int i = 0; i < node->quantityErrorStudent; i++) {
                if (node->errorStudent[i] != 0) {
                    err_Student[i](node->errorStudent[i]);
                    cout << endl;
                }
            }
            for (int i = 0; i < node->quantityErrorRecord; i++) {
                if (node->errorRecord[i] != 0) {
                    err_Record[i](node->errorRecord[i]);
                    cout << endl;
                }
            }
            for (int i = 0; i < node->quantityErrorUnique; i++) {
                if (node->errorUnique[i] != 0) {
                    err_Unique[i](node->errorUnique[i]);
                    cout << endl;
                }
            }
        }

        node = node->next;
    }
}