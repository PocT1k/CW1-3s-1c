#include "Functions.h"

using namespace std;


void test() {
    cout << "------------------------------------" << endl;
    //cout << INT_MAX << endl;


    //char c = 't';
    //cout << c << endl;

    //ofstream fout;
    //fout.open("��������1.ins");
    //fout << "123 �� ��� Yes No";
    //fout.close();
    //ifstream fin;
    //fin.open("��������1.ins");
    //string str1;
    //getline(fin, str1);
    //cout << str1 << endl;


    cout << "------------------------------------" << endl;
}

//typedef int (*Func)(int);
//Func Keys_Funcs[] = { GetIndexKey_Start, GetIndexKey_Middle, GetIndexKey_End };

void readLine(string& strLine, LineNode* line) {
    //line->coutStr();

    checkLine checkLineFile_Start[] = { checkLine_Syntax, checkLine_Type, checkLine_AmountData }; //���������� �������� ������
    checkLine checkLineFile_Total[] = { checkLine_Number, checkLine_ChecksumNumber, checkLine_Surname, checkLine_Name, checkLine_Patronymic, checkLine_Institute, checkLine_Faculty, checkLine_Training , checkLine_Course, checkLine_Group, checkLine_Payment, checkLine_Year, checkLine_Department, checkLine_Date }; //����� �������� �����
    checkLine checkLineFile_Student[] = { checkLine_Gender, checkLine_Address, checkLine_Status }; //�������� �������� ��� �����
    checkLine checkLineFile_Record[] = { checkLine_Subject, checkLine_TeacherSurname, checkLine_TeacherName, checkLine_TeacherPatronymic, checkLine_Value, checkLine_Room }; //�������� ��������� ��� �����
    int size_checkLineFile_Start = sizeof(checkLineFile_Start) / sizeof(checkLineFile_Start[0]);
    int size_checkLineFile_Total = sizeof(checkLineFile_Total) / sizeof(checkLineFile_Total[0]);
    int size_checkLineFile_Student = sizeof(checkLineFile_Student) / sizeof(checkLineFile_Student[0]);
    int size_checkLineFile_Record = sizeof(checkLineFile_Record) / sizeof(checkLineFile_Record[0]);

    line->errorLine[0] = checkLine_Lenght(strLine, line);
    if (line->errorLine[0] == 0) {
        for (int i = 0; i < size_checkLineFile_Start; i++) {
            line->errorLine[i] = checkLineFile_Start[i](strLine, line);
        }
        line->setErr();
        if (line->getErr() == 0) {
            for (int i = 4; i < (size_checkLineFile_Total + 4); i++) {
                line->errorLine[i] = checkLineFile_Total[i - 4](strLine, line);
            }

            if (line->type == 'S') {
                for (int i = 0; i < size_checkLineFile_Student; i++) {
                    line->errorLine[i] = checkLineFile_Student[i](strLine, line);
                }
            }
            if (line->type == 'R') {
                for (int i = 0; i < size_checkLineFile_Record; i++) {
                    line->errorLine[i] = checkLineFile_Record[i](strLine, line);
                }
            }
            line->setErr();
            if (line->getErr() == 0) {
                line->errorLine[18] = checkLine_ChecksumData(strLine, line);
            }
        }
    }
    line->setErr();

    //line->coutError();
}

void readFileLine(istream& stream, InstituteNode& institute) {
    string strLine = "";
    getline(stream, strLine);
    strLine = deleteSpace(strLine);
    if (strLine == "") {
        return;
    }

    LineNode* line = new LineNode;
    line->createStr(strLine);

    readLine(strLine, line);

    institute.add(line);
}

void readFromFile(InstituteNode& institute) {
    cout << endl;
    ifstream instituteDataFile;
    instituteDataFile.open(institute.fileToWork);

    if (!instituteDataFile) {
        cout << "������ ������ ����� " << institute.fileToWork << endl;
        return;
    }
    if (!instituteDataFile.is_open()) {
        cout << "������ �������� ����� " << institute.fileToWork << endl;
        return;
    }
    cout << "������ ���� " << institute.fileToWork << endl;

    istream* stream = nullptr;
    stream = &instituteDataFile;

    while (!stream->eof()) {
        readFileLine(*stream, institute);
    }
    instituteDataFile.close();

    cout << "������ ����� " << institute.fileToWork << " ���������" << endl;
    cout << "������� ��������� " << institute.nodeSuccess << " " << institute.worlEnd_������[getWordEnd(institute.nodeSuccess)] << endl;
    if (institute.nodeMistake != 0) {
        cout << "�� ������� ��������� " << institute.nodeMistake << " " << institute.worlEnd_������[getWordEnd(institute.nodeMistake)] << endl;
        cout << "������ �� ����������� �������:" << endl;
    }
    else {
        cout << "�� ����������� ������� ���" << endl;
    }

    institute.resetSM();
    institute.printFailList(1);
    institute.printStudents();
    institute.printRecords();
}

void writeNumber(ostream& stream, string* number) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            stream << number[i][j];
        }
        if (i != 7) {
            stream << "-";
        }
    }
}

void writeStudentLine(ostream& stream, StudentNode* node) {
    stream << "[S]:";
    writeNumber(stream, node->number);
    node->writeGeneral(stream, node);
    stream << node->gender << ";" << node->address << ";" << node->status;
    stream << ";" << node->checksumData;
    stream << ";";
    stream << endl;
}

void writeRecordLine(ostream& stream, RecordNode* node) {
    stream << "[R]:";
    writeNumber(stream, node->number);
    node->writeGeneral(stream, node);
    stream << node->subject << ";" << node->teacherSurname << ";" << node->teacherName << ";" << node->teacherPatronymic << ";" << node->value << ";" << node->room;
    stream << ";" << node->checksumData;
    stream << ";";
    stream << endl;
}

void writeFailLine(ostream& stream, LineNode* node) {
    stream << node->getStr();
    stream << endl;
}

void writeToFile(InstituteNode& institute, int flag) {
    cout << endl;
    ofstream instituteDataFile;
    instituteDataFile.open(institute.fileToWork);

    if (!instituteDataFile) {
        cout << "������ �������� ����� " << institute.fileToWork << endl;
        return;
    }
    if (!instituteDataFile.is_open()) {
        cout << "������ �������� ����� " << institute.fileToWork << endl;
        return;
    }
    cout << "������ ���� " << institute.fileToWork << endl;

    ostream* stream = nullptr;
    stream = &instituteDataFile;

    StudentNode* nodeS = institute.headStudentsList;
    while (nodeS != nullptr) {
        writeStudentLine(*stream, nodeS);
        institute.nodeSuccess++;
        nodeS = nodeS->nextNode(nodeS);
    }

    RecordNode* nodeR = institute.headRecordsList;
    while (nodeR != nullptr) {
        writeRecordLine(*stream, nodeR);
        institute.nodeSuccess++;
        nodeR = nodeR->nextNode(nodeR);
    }

    if (flag) {
        LineNode* nodeF = institute.failList;
        while (nodeF != nullptr) {
            writeFailLine(*stream, nodeF);
            institute.nodeMistake++;
            nodeF = nodeF->nextNode(nodeF);
        }
    }

    instituteDataFile.close();

    cout << "����� ����� " << institute.fileToWork << " ���������" << endl;
    cout << "������� ��������� " << institute.nodeSuccess << " " << institute.worlEnd_������[getWordEnd(institute.nodeSuccess)];
    if (institute.nodeMistake != 0) {
        cout << " � " << institute.nodeMistake << " �� ������������� " << institute.worlEnd_������[getWordEnd(institute.nodeMistake)];
    }
    cout << endl;
    institute.resetSM();
}

InstituteNode createInstitutesList() {
    InstituteNode institute;
    institute.fileToWork = institute.path + institute.file + institute.expansion;
    institute.fileTheName = institute.path + institute.file + institute.expansion;

    readFromFile(institute);

    return institute;
}