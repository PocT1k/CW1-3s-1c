#include "Struct.h"

using namespace std;

void Node::printNumber() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            cout << number[i][j];
        }
    }
    cout << endl;
}

void LineNode::printError() {
    for (int i = 0; i < quantityError; i++) {
        cout << error[i];
    }
    cout << endl;
}

void InstituteNode::add() {
    ;
}