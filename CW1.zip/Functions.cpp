#include "Functions.h"

using namespace std;


void test() {
    cout << "------------------------------------" << endl;
    //cout << INT_MAX << endl;


    //char c = 't';
    //cout << c << endl;

    //ofstream fout;
    //fout.open("��������1.ins");
    //fout << "123 �� ��� Yes No";
    //fout.close();
    //ifstream fin;
    //fin.open("��������1.ins");
    //string str1;
    //getline(fin, str1);
    //cout << str1 << endl;


    //string str1 = "0123456789qwertyuiop[]asdfghjkl'";
    //string str1 = "rdtrytgkjnbvsyxedtnymgkcxtyrtfyn";
    //cout << "������ " << str1 << endl;
    //string str2 = getChecksum(str1);
    //cout << "�������� " << str2 << endl;


    cout << "------------------------------------" << endl;
}

HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
void goToXY(short x, short y) {
    SetConsoleCursorPosition(hStdOut, { x, y});
}

string deleteSpace(string& str) {
    str.erase(str.find(' '), 1);
    if (str[0] == ' ') {
        str = deleteSpace(str);
    }
    return str;
}

string addZero(string str) {
    str = '0' + str;
    if (str.length() < 6) {
        str = addZero(str);
    }
    return str;
}

string getChecksum(string str) {
    if (str.size() % 2 == 1) {
        str = str + 'm';
    }
    int sum = 0;
    int mul;
    int div;
    for (int i = 0; i < str.size(); i = i + 2) {
        mul = str[i] * str[i + 1];
        div = str[i] / str[i + 1];
        sum = sum + mul + div;  
    }
    sum = sum % 1000000;
    str = to_string(sum);
    if (str.length() < 6) {
        str = addZero(str);
    }
    return str;
}

bool isDigit(char ch) {
    if (('0' <= ch) && (ch <= '9')) {
        return 1;
    }
    return 0;
}

bool isBigRus(char ch) {
    if (('�' <= ch) && (ch <= '�')) {
        return 1;
    }
    return 0;
}

bool isSmallRus(char ch) {
    if (('�' <= ch) && (ch <= '�')) {
        return 1;
    }
    return 0;
}

bool checkNumber(char ch) {
    if ((isDigit(ch) == 1) || (isBigRus(ch) == 1) || (ch == ' ') || (ch == '-')) {
        return 1;
    }
    return 0;
}

string getStringBeforeSep(string& strLine, LineNode& line) {
    int i = 0;
    while ((strLine[i] != '\0') && (strLine[i] != line.sep)) {
        i++;
    }
    string str = strLine.substr(0, i);
    line.len = line.len - i;
    if (strLine.length() > 0) {
        strLine = strLine.substr(i + 1, strLine.length() - 1);
    }
    //cout << "���������� " << i << " �������� " << str << endl;
    //cout << "����� " << line.str << endl;
    return str;
}

//int getSep(string& str, char sep) {
//    int i = 0;
//    while ((str[i] != '\0') && (str[i] != ' ') && (str[i] != sep)) {
//        i++;
//    }
//    return i;
//}

void checkLine_Lenght(string& strLine, LineNode& line) {

    if (strLine[0] == ' ') {
        strLine = deleteSpace(strLine);
    }

    while (strLine[line.len] != '\0') {
        if (strLine[line.len] == line.sep) {
            line.amountDataThis++;
        }
        line.len++;
    }
    if (line.len < line.lenStrMin) {
        line.error[0] = 1;
        line.error[line.quantityError - 1] = 1;
    }
}

void checkLine_Syntax(string& strLine, LineNode& line) {
    if ((strLine[0] != '[') || (strLine[2] != ']') || (strLine[3] != ':') || (strLine[8] != '-') || (strLine[13] != '-') || (strLine[18] != '-') || (strLine[23] != '-') || (strLine[28] != '-') || (strLine[33] != '-') || (strLine[38] != '-') || (strLine[43] != ';') || (strLine[50] != ';')) {
        line.error[1] = 1;
        line.error[line.quantityError - 1] = 1;
    }
}

void checkLine_Type(string& strLine, LineNode& line) {
    if (strLine[1] == 'S') {
        line.type = 'S';
    }
    if (strLine[1] == 'R') {
        line.type = 'R';
    }
    if (!line.type) {
        line.error[2] = 1;
        line.error[line.quantityError - 1] = 1;
    }
}

void checkLine_AmountData(string& strLine, LineNode& line) {
    if (line.type == 'S') {
        if (line.amountDataThis != line.amountDataMinStudent) {
            line.error[3] = 1;
            line.error[line.quantityError - 1] = 1;
        }
        return;
    }
    if (line.type == 'R') {
        if (line.amountDataThis != line.amountDataMinRecord) {
            line.error[3] = 1;
            line.error[line.quantityError - 1] = 1;
        }
        return;
    }
    if (line.amountDataThis != line.amountDataMin) {
        line.error[3] = 1;
        line.error[line.quantityError - 1] = 1;
    }
}

void checkLine_CorrectNumber(string& strLine, LineNode& line) {
    string number = getStringBeforeSep(strLine, line);
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            //cout << number[4 + i * 5 + j] << " " << checkNumber(number[4 + i * 5 + j]) << " ";
            if (checkNumber(number[4 + i * 5 + j]) == 1) {
                line.number[i][j] = number[4 + i * 5 + j];
            }
            else {
                line.error[4] = 1;
                line.error[line.quantityError - 1] = 1;
            }
        }
    }
}

void checkLine_CheckChecksum(string& strLine, LineNode& line) {
    string number;
    string checksumNumber = getStringBeforeSep(strLine, line);
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            number = number + line.number[i][j];
        }
    }
    
    if (getChecksum(number) != (checksumNumber)) {
        line.error[5] = 1;
        line.error[line.quantityError - 1] = 1;
    }
    else {
        line.checksumNumber = checksumNumber;
    }
}

void checkLine_Surname(string& strLine, LineNode& line) {
    string surname = getStringBeforeSep(strLine, line);
    if (surname != "") {
        if (isBigRus(surname[0]) == 0) {
            line.error[6] = 1;
            line.error[line.quantityError - 1] = 1;
        }
        int i = 1;
        while (surname[i] != '\0') {
            if (isSmallRus(surname[i]) == 0) {
                line.error[6] = 1;
                line.error[line.quantityError - 1] = 1;
            }
            i++;
        }
        if (line.error[6] == 0) {
            line.surname = surname;
        }
    }
}

void checkLine_Name(string& strLine, LineNode& line) {
    string name = getStringBeforeSep(strLine, line);
    if (isBigRus(name[0]) == 0) {
        line.error[7] = 1;
        line.error[line.quantityError - 1] = 1;
    }
    int i = 1;
    while (name[i] != '\0') {
        if (isSmallRus(name[i]) == 0) {
            line.error[7] = 1;
            line.error[line.quantityError - 1] = 1;
        }
        i++;
    }
    if (line.error[7] == 0) {
        line.name = name;
    }
}

void checkLine_Patronymic(string& strLine, LineNode& line) {
    string patronymic = getStringBeforeSep(strLine, line);
    if (patronymic != "") {
        if (isBigRus(patronymic[0]) == 0) {
            line.error[8] = 1;
            line.error[line.quantityError - 1] = 1;
        }
        int i = 1;
        while (patronymic[i] != '\0') {
            if (isSmallRus(patronymic[i]) == 0) {
                line.error[8] = 1;
                line.error[line.quantityError - 1] = 1;
            }
            i++;
        }
        if (line.error[8] == 0) {
            line.patronymic = patronymic;
        }
    }
}

void checkLine_Institute(string& strLine, LineNode& line) {
    string institute = getStringBeforeSep(strLine, line);
    if (institute.length() != 1) {
        line.error[9] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    if ((institute[0] != '�') && (institute[0] != 'M')) {
        line.error[9] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    line.institute = institute[0];
}

void checkLine_Faculty(string& strLine, LineNode& line) {
    string faculty = getStringBeforeSep(strLine, line);
    if ((faculty.length() == 0) || (faculty.length() > 2)) {
        line.error[10] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    int i = 0;
    while (faculty[i] != '\0') {
        if (isDigit(faculty[i]) == 0) {
            line.error[10] = 1;
            line.error[line.quantityError - 1] = 1;
            return;
        }
        i++;
    }
    line.faculty = stoi(faculty);
    cout << line.faculty << endl;
}

void checkLine_Training(string& strLine, LineNode& line) {
    string training = getStringBeforeSep(strLine, line);
    if (training.length() == 1) {
        if ((training[0] == '�') || (training[0] == 'O') || (training[0] == '�')) {
            if (training[0] == '�') {
                line.training = '�';
            }
            else {
                line.training = '�';
            }
        }
        return;
    }
    if ((training == "��") || (training == "O�")) {
        line.training = '��';
        return;
    }
    line.error[11] = 1;
    line.error[line.quantityError - 1] = 1;
}

void checkLine_Course(string& strLine, LineNode& line) {
    string course = getStringBeforeSep(strLine, line);
    if (course.length() != 1) {
        line.error[12] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    if (isDigit(course[0]) == 0) {
        line.error[12] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    int courseDigit = stoi(course);
    if ((courseDigit < 0) || (courseDigit > 6)) {
        line.error[12] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    line.course = courseDigit;
}

void checkLine_Group(string& strLine, LineNode& line) {
    string group = getStringBeforeSep(strLine, line);
    if (group.length() != 2) {
        line.error[13] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    if ((isDigit(group[0]) == 0) || (isDigit(group[1]) == 0)) {
        line.error[13] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    line.group = stoi(group);
}

void checkLine_Payment(string& strLine, LineNode& line) {
    string payment = getStringBeforeSep(strLine, line);
    if (payment.length() == 1) {
        if ((payment[0] == '�') || (payment[0] == 'K') || (payment[0] == '�')) {
            if (payment[0] == '�') {
                line.payment = '�';
            }
            else {
                line.payment = '�';
            }
        }
        return;
    }
    if ((payment == "��") || (payment == "�k")) {
        line.payment = '��';
        return;
    }
    line.error[14] = 1;
    line.error[line.quantityError - 1] = 1;
}

void checkLine_Year(string& strLine, LineNode& line) {
    string year = getStringBeforeSep(strLine, line);
    if (year.length() != 4) {
        line.error[15] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    for (int i = 0; i < 4; i++) {
        if (isDigit(year[i]) == 0) {
            line.error[15] = 1;
            line.error[line.quantityError - 1] = 1;
            return;
        }
    }
    int yearDigit = stoi(year);
    if (yearDigit < 1930) {
        line.error[15] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    line.year = yearDigit;
}

void checkLine_Department(string& strLine, LineNode& line) {
    string department = getStringBeforeSep(strLine, line);
    if (department.length() != 3) {
        line.error[16] = 1;
        line.error[line.quantityError - 1] = 1;
        return;
    }
    for (int i = 0; i < 3; i++) {
        if (isDigit(department[i]) == 0) {
            line.error[16] = 1;
            line.error[line.quantityError - 1] = 1;
            return;
        }
    }
    line.department = stoi(department);
}

void checkLine_7(string& strLine, LineNode& line) {

}

void readLine(string& strLine, LineNode& line, InstituteNode& institute) {
    cout << "�����:" << strLine << endl;

    checkLine_Lenght(strLine, line);
    if (line.error[0] != 1) {
        checkLine_Syntax(strLine, line);
        checkLine_Type(strLine, line);
        checkLine_AmountData(strLine, line);
        checkLine_CorrectNumber(strLine, line);
        checkLine_CheckChecksum(strLine, line);
        checkLine_Surname(strLine, line);
        checkLine_Name(strLine, line);
        checkLine_Patronymic(strLine, line);
        checkLine_Institute(strLine, line);
        checkLine_Faculty(strLine, line);
        checkLine_Training(strLine, line);
        checkLine_Course(strLine, line);
        checkLine_Group(strLine, line);
        checkLine_Payment(strLine, line);
        checkLine_Year(strLine, line);
        checkLine_Department(strLine, line);
        
    }

    line.printError();
}

void readFileLine(istream& stream, InstituteNode& institute) {
    string strLine;
    getline(stream, strLine);
    LineNode line(institute);

    readLine(strLine, line, institute);
}

int readFromFile(InstituteNode& institute) {
    ifstream instituteDataFile;
    instituteDataFile.open(institute.fileToOpen);

    if (!instituteDataFile) {
        cout << "������ ������ ����� " << institute.fileToOpen << endl;
        return 1;
    }
    if (!instituteDataFile.is_open()) {
        cout << "������ �������� ����� " << institute.fileToOpen << endl;
        return 2;
    }
    cout << "������ ���� " << institute.fileToOpen << endl;

    istream* stream = nullptr;
    stream = &instituteDataFile;

    while (!stream->eof()) {
        readFileLine(*stream, institute);
    }
    return 0;
}

InstituteNode createInstitutesList() {
    InstituteNode institute;
    institute.fileToOpen = institute.path + institute.file + institute.expansion;
    institute.fileTheName = institute.path + institute.file + institute.expansion;

    int error;
    error = readFromFile(institute);

    return institute;
}