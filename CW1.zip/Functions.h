#ifndef CW_FUNCTIONS_H
#define CW_FUNCTIONS_H

#include <iostream> //�������
#include <fstream> //�����
#include <Windows.h> //�������
#include <chrono> //�����
#include <climits> //���������
#include <iomanip> //��,���
#include <string> //������
#include <conio.h> //"�������"

#include "Struct.h"

void test();

void goToXY(short x, short y);

//StudentNode* createStudentsList();
string deleteSpace(string& str);
string addZero(string str);
string getChecksum(string str);
bool isDigit(char ch);
bool isBigRus(char ch);
bool isSmallRus(char ch);
bool checkNumber(char ch);
string getStringBeforeSep(string& strLine, LineNode& line);

void checkLine_Lenght(string& strLine, LineNode& line);
void checkLine_Syntax(string& strLine, LineNode& line);
void checkLine_Type(string& strLine, LineNode& line);
void checkLine_AmountData(string& strLine, LineNode& line);
void checkLine_CorrectNumber(string& strLine, LineNode& line);
void checkLine_CheckChecksum(string& strLine, LineNode& line);
void checkLine_Surname(string& strLine, LineNode& line);
void checkLine_Name(string& strLine, LineNode& line);
void checkLine_Patronymic(string& strLine, LineNode& line);
void checkLine_Institute(string& strLine, LineNode& line);
void checkLine_Faculty(string& strLine, LineNode& line);
void checkLine_Training(string& strLine, LineNode& line);
void checkLine_Course(string& strLine, LineNode& line);
void checkLine_Group(string& strLine, LineNode& line);
void checkLine_Payment(string& strLine, LineNode& line);
void checkLine_Year(string& strLine, LineNode& line);
void checkLine_Department(string& strLine, LineNode& line);

void checkLine_7(string& strLine, LineNode& line);

void readLine(string& strLine, LineNode& line, InstituteNode& institute);
void readFileLine(istream& stream, InstituteNode& institute);
int readFromFile(InstituteNode& institute);
InstituteNode createInstitutesList();

#endif