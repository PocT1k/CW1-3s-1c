#include "Functions.h"

using namespace std;


void test() {
    cout << "------------------------------------" << endl;
    //cout << INT_MAX << endl;


    //char c = 't';
    //cout << c << endl;

    //ofstream fout;
    //fout.open("��������1.ins");
    //fout << "123 �� ��� Yes No";
    //fout.close();
    //ifstream fin;
    //fin.open("��������1.ins");
    //string str1;
    //getline(fin, str1);
    //cout << str1 << endl;


    cout << "------------------------------------" << endl;
}

//typedef int (*Func)(int);
//Func Keys_Funcs[] = { GetIndexKey_Start, GetIndexKey_Middle, GetIndexKey_End };

void readLine(string& strLine, LineNode* line) {
    //line->coutStr();

    line->errorLine[0] = checkLine_Lenght(strLine, line);
    if (line->errorLine[0] == 0) {
        line->errorLine[1] = checkLine_Syntax(strLine, line);
        line->errorLine[2] = checkLine_Type(strLine, line);
        line->errorLine[3] = checkLine_AmountData(strLine, line);
        line->setErr();
        if (line->getErr() == 0) {
            line->errorLine[4] = checkLine_Number(strLine, line);
            line->errorLine[5] = checkLine_ChecksumNumber(strLine, line);
            line->errorLine[6] = checkLine_Surname(strLine, line);
            line->errorLine[7] = checkLine_Name(strLine, line);
            line->errorLine[8] = checkLine_Patronymic(strLine, line);
            line->errorLine[9] = checkLine_Institute(strLine, line);
            line->errorLine[10] = checkLine_Faculty(strLine, line);
            line->errorLine[11] = checkLine_Training(strLine, line);
            line->errorLine[12] = checkLine_Course(strLine, line);
            line->errorLine[13] = checkLine_Group(strLine, line);
            line->errorLine[14] = checkLine_Payment(strLine, line);
            line->errorLine[15] = checkLine_Year(strLine, line);
            line->errorLine[16] = checkLine_Department(strLine, line);
            line->errorLine[17] = checkLine_Date(strLine, line);
            if (line->type == 'S') {
                line->errorStudent[0] = checkLine_Gender(strLine, line);
                line->errorStudent[1] = checkLine_Address(strLine, line);
                line->errorStudent[2] = checkLine_Status(strLine, line);
            }
            if (line->type == 'R') {
                line->errorRecord[0] = checkLine_Subject(strLine, line);
                line->errorRecord[1] = checkLine_TeacherSurname(strLine, line);
                line->errorRecord[2] = checkLine_TeacherName(strLine, line);
                line->errorRecord[3] = checkLine_TeacherPatronymic(strLine, line);
                line->errorRecord[4] = checkLine_Value(strLine, line);
                line->errorRecord[5] = checkLine_Room(strLine, line);
            }
            line->setErr();
            if (line->getErr() == 0) {
                line->errorLine[18] = checkLine_ChecksumData(strLine, line);
            }
        }
    }
    line->setErr();

    //line->coutError();
}

void readFileLine(istream& stream, InstituteNode& institute) {
    string strLine;
    getline(stream, strLine);
    strLine = deleteSpace(strLine);
    if (strLine == "") {
        return;
    }

    LineNode* line = new LineNode;
    line->createStr(strLine);

    readLine(strLine, line);

    institute.add(line);
}

void readFromFile(InstituteNode& institute) {
    cout << endl;
    ifstream instituteDataFile;
    instituteDataFile.open(institute.fileToWork);

    if (!instituteDataFile) {
        cout << "������ ������ ����� " << institute.fileToWork << endl;
        return;
    }
    if (!instituteDataFile.is_open()) {
        cout << "������ �������� ����� " << institute.fileToWork << endl;
        return;
    }
    cout << "������ ���� " << institute.fileToWork << endl;

    istream* stream = nullptr;
    stream = &instituteDataFile;

    while (!stream->eof()) {
        readFileLine(*stream, institute);
    }
    instituteDataFile.close();

    cout << "������ ����� " << institute.fileToWork << " ���������" << endl;
    cout << "������� ��������� " << institute.nodeSuccess << " " << institute.worlEnd_������[getWordEnd(institute.nodeSuccess)] << endl;
    if (institute.nodeMistake != 0) {
        cout << "�� ������� ��������� " << institute.nodeMistake << " " << institute.worlEnd_������[getWordEnd(institute.nodeMistake)] << endl;
        cout << "������ �� ����������� �������:" << endl;
    }
    else {
        cout << "�� ����������� ������� ���" << endl;
    }

    institute.resetSM();
    institute.printFailList(1);
    institute.printStudents();
    institute.printRecords();
}

void writeNumber(ostream& stream, string* number) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 4; j++) {
            stream << number[i][j];
        }
        if (i != 7) {
            stream << "-";
        }
    }
}

void writeStudentLine(ostream& stream, StudentNode* node) {
    stream << "[S]:";
    writeNumber(stream, node->number);
    node->writeGeneral(stream, node);
    stream << node->gender << ";" << node->address << ";" << node->status;
    stream << ";" << node->checksumData;
    stream << ";";
    stream << endl;
}

void writeRecordLine(ostream& stream, RecordNode* node) {
    stream << "[R]:";
    writeNumber(stream, node->number);
    node->writeGeneral(stream, node);
    stream << node->subject << ";" << node->teacherSurname << ";" << node->teacherName << ";" << node->teacherPatronymic << ";" << node->value << ";" << node->room;
    stream << ";" << node->checksumData;
    stream << ";";
    stream << endl;
}

void writeFailLine(ostream& stream, LineNode* node) {
    stream << node->getStr();
    stream << endl;
}

void writeToFile(InstituteNode& institute, int flag) {
    cout << endl;
    ofstream instituteDataFile;
    instituteDataFile.open(institute.fileToWork);

    if (!instituteDataFile) {
        cout << "������ �������� ����� " << institute.fileToWork << endl;
        return;
    }
    if (!instituteDataFile.is_open()) {
        cout << "������ �������� ����� " << institute.fileToWork << endl;
        return;
    }
    cout << "������ ���� " << institute.fileToWork << endl;

    ostream* stream = nullptr;
    stream = &instituteDataFile;

    StudentNode* nodeS = institute.headStudentsList;
    while (nodeS != nullptr) {
        writeStudentLine(*stream, nodeS);
        institute.nodeSuccess++;
        nodeS = nodeS->nextNode(nodeS);
    }

    RecordNode* nodeR = institute.headRecordsList;
    while (nodeR != nullptr) {
        writeRecordLine(*stream, nodeR);
        institute.nodeSuccess++;
        nodeR = nodeR->nextNode(nodeR);
    }

    if (flag) {
        LineNode* nodeF = institute.failList;
        while (nodeF != nullptr) {
            writeFailLine(*stream, nodeF);
            institute.nodeMistake++;
            nodeF = nodeF->nextNode(nodeF);
        }
    }

    instituteDataFile.close();

    cout << "����� ����� " << institute.fileToWork << " ���������" << endl;
    cout << "������� ��������� " << institute.nodeSuccess << " " << institute.worlEnd_������[getWordEnd(institute.nodeSuccess)];
    if (institute.nodeMistake != 0) {
        cout << " � " << institute.nodeMistake << " �� ������������� " << institute.worlEnd_������[getWordEnd(institute.nodeMistake)];
    }
    cout << endl;
    institute.resetSM();
}

InstituteNode createInstitutesList() {
    InstituteNode institute;
    institute.fileToWork = institute.path + institute.file + institute.expansion;
    institute.fileTheName = institute.path + institute.file + institute.expansion;

    readFromFile(institute);

    return institute;
}